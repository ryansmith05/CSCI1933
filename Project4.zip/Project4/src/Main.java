import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choose a difficulty level:");
        System.out.println("1. Easy (5x5, 5 mines, 5 flags)");
        System.out.println("2. Medium (9x9, 12 mines, 12 flags)");
        System.out.println("3. Hard (20x20, 40 mines, 40 flags)");

        int choice = scanner.nextInt();

        int rows = 0;
        int columns = 0;
        int mines = 0;

        if (choice == 1) {
            rows = 5;
            columns = 5;
            mines = 5;
        } else if (choice == 2) {
            rows = 9;
            columns = 9;
            mines = 12;
        } else if (choice == 3) {
            rows = 20;
            columns = 20;
            mines = 40;
        } else {
            System.out.println("Invalid choice, Exiting.");
            scanner.close();
            return;
        }

        System.out.println("Enable debug mode? (y/n)");
        boolean debugMode = scanner.next().equalsIgnoreCase("y");

        Minefield minefield = new Minefield(rows, columns, mines);
        boolean firstMove = true;

        scanner.nextLine();

        while (!minefield.gameOver()) {
            System.out.println(minefield.toString());

            if (debugMode) {
                System.out.println("Debug mode: ");
                minefield.printMinefield();
            }

            System.out.println("Flags remaining: " + minefield.getFlagsRemaining());

            System.out.print("Enter your move [row SPACE col] or (row SPACE col SPACE F) to place a flag: \n");
            String inputLine = scanner.nextLine();
            String[] inputs = inputLine.split(" ");
            int row = Integer.parseInt(inputs[0]);
            int col = Integer.parseInt(inputs[1]);

            boolean flag = false;
            if (inputs.length == 3 && inputs[2].equalsIgnoreCase("F")) {
                flag = true;
            }

            if (firstMove && !flag) {
                minefield.createMines(row, col, mines);
                minefield.evaluateField();
                minefield.guess(row, col, flag);
                firstMove = false;
            } else {
                boolean hitMine = minefield.guess(row, col, flag);
                if (hitMine) {
                    System.out.println("You hit a mine! Game over.");
                    break;
                }
            }
        }

        System.out.println("Final minefield:");
        minefield.printMinefield();

        scanner.close();
    }
}