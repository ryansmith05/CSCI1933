//import java.util.LinkedList;
//import java.util.Queue;
//import java.util.Random;
//
//public class Minefield {
//    /**
//     * Global Section
//     */
//    public static final String ANSI_YELLOW = "\u001B[33m";
//    public static final String ANSI_BLUE_BRIGHT = "\u001b[34;1m";
//    public static final String ANSI_BLUE = "\u001b[34m";
//    public static final String ANSI_RED_BRIGHT = "\u001b[31;1m";
//    public static final String ANSI_RED = "\u001b[31m";
//    public static final String ANSI_GREEN = "\u001b[32m";
//    public static final String ANSI_GREY_BG = "\u001b[0m";
//
//    private int rows;
//    private int columns;
//    private int flags;
//    private int mines;
//    private Cell[][] field;
//    private boolean gameOver;
//    private boolean[][] flagged;
//
//
//    /**
//     * Constructor
//     *
//     * @param rows    Number of rows.
//     * @param columns Number of columns.
//     * @param flags   Number of flags, should be equal to mines
//     */
//    public Minefield(int rows, int columns, int flags) {
//        this.rows = rows;
//        this.columns = columns;
//        this.flags = flags;
//        this.mines = flags;
//        this.field = new Cell[rows][columns];
//        this.gameOver = false;
//        this.flagged = new boolean[rows][columns];
//
//
//        // Initialize all cells
//        for (int row = 0; row < rows; row++) {
//            for (int col = 0; col < columns; col++) {
//                field[row][col] = new Cell(false, "0");
//            }
//        }
//    }
//
//    /**
//     * evaluateField
//     *
//     * @function When a mine is found in the field, calculate the surrounding 9x9 tiles values. If a mine is found, increase the count for the square.
//     */
//    public void evaluateField() {
//        for (int row = 0; row < rows; row++) {
//            for (int col = 0; col < columns; col++) {
//                if (!field[row][col].getStatus().equals("M")) {
//                    int minesCount = 0;
//
//                    for (int i = -1; i <= 1; i++) {
//                        for (int j = -1; j <= 1; j++) {
//                            int newRow = row + i;
//                            int newCol = col + j;
//
//                            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns && field[newRow][newCol].getStatus().equals("M")) {
//                                minesCount++;
//                                field[row][col].setStatus(Integer.toString(minesCount));
//
//                            }
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    /**
//     * createMines
//     *
//     * @param x     Start x, avoid placing on this square.
//     * @param y     Start y, avoid placing on this square.
//     * @param mines Number of mines to place.
//     */
//
////    This method will place all of our mines on our field. Until all mines has been placed, the method
////    should randomly generate coordinates to place a mine. Before placing a mine, the method should
////    check to see if this coordinate has not been revealed and is not already a mine, and is not equal
////    to the starting coordinates. Otherwise, a new coordinate pair should be generated.
//    public void createMines(int x, int y, int mines) {
//        Random random = new Random();
//        int placedMines = 0;
//
//        while (placedMines < mines) {
//            int row = random.nextInt(rows);
//            int col = random.nextInt(columns);
//
//            // Avoid placing a mine on the starting coordinates
//            if (row == x && col == y) {
//                continue;
//            }
//
//            // Check if the cell is empty and not already a mine
//            if (field[row][col] == null || !field[row][col].getStatus().equals("M")) {
//                field[row][col] = new Cell(false, "M");
//                placedMines++;
//            }
//        }
//    }
//
//
//    /**
//     * guess
//     *
//     * @param x    The x value the user entered.
//     * @param y    The y value the user entered.
//     * @param flag A boolean value that allows the user to place a flag on the corresponding square.
//     * @return boolean Return false if guess did not hit mine or if flag was placed, true if mine found.
//     */
////    When a user guesses a coordinate, the guess() method should do the following. It first should see
////if the guess is in-bounds—this may also be done in the Main class. Next, it should see if the user
////    wishes to place a flag and, if so, whether or not there are enough flags remaining to place the flag.
////    If the user did not place a flag, then the method should check to see if the user has hit a cell with
////    a ’0’ status. If so, call the revealZeroes() method
////    Finally, if the user hits a mine, end the game. Make sure to also set the revealed status of the cell
////    that the user guesses at the end of the method
//    public boolean guess(int x, int y, boolean flag) {
//// Check if the guess is in-bounds
//        if (x < 0 || x >= rows || y < 0 || y >= columns) {
//            return false;
//        }
//        Cell cell = field[x][y];
//
//        // If the user wishes to place a flag
//        if (flag) {
//            if (!cell.getRevealed()) {
//                if (flagged[x][y]) {
//                    flagged[x][y] = false;
//                    flags++;
//                } else if (flags > 0) {
//                    flagged[x][y] = true;
//                    flags--;
//                }
//            }
//            return false;
//        }
//
//// If the cell is already revealed, do nothing
//        if (cell.getRevealed()) {
//            return false;
//        }
//
//// Reveal the cell
//        cell.setRevealed(true);
//
//// If the user hits a cell with a '0' status
//        if (cell.getStatus().equals("0")) {
//            revealZeroes(x, y);
//            return false;
//        }
//
//// If the user hits a mine, end the game
//        if (cell.getStatus().equals("M")) {
//            gameOver = true;
//            return true;
//        }
//
//        return false;
//    }
//
//    /**
//     * gameOver
//     *
//     * @return boolean Return false if game is not over and squares have yet to be revealed, otheriwse return true.
//     */
//    public boolean gameOver() {
//        return gameOver;
//    }
//
//    /**
//     * revealField
//     * <p>
//     * This method should follow the psuedocode given.
//     * Why might a stack be useful here rather than a queue?
//     *
//     * @param x The x value the user entered.
//     * @param y The y value the user entered.
//     */
////    This method is used to reveal all surrounding zeroes when a user clicks on a square containing a
////    status of ”0”. At the bottom of the description you will see the desired output, notice how guessing
////    one zero reveals all zeroes nearby. Here we are using an algorithm using a stack to accomplish this.
////    Since a stack has a first-in-last-out structure, this will explore as far in one direction as possible for
////    a ’0’ status. The pseudo-code is as follows:
////            • Initialize a stack with the start index {x, y}. This should be the x and y values passed into
////    the method.
////            • Loop until the stack is empty:
////            – Get the top element off the stack.
////– Set the corresponding cell’s revealed attribute as true.
////            ∗ Push all valid neighbor’s coordinates to the stack. A valid neighbor is one who is
////    in-bounds, has not previously been revealed, and whose status is ”0”.
////            – Neighbors here are the cells located to the left, right, above, and down from the current cell.
//    public void revealZeroes(int x, int y) {
//        Stack1Gen<int[]> stack = new Stack1Gen<>();
//
//        // Initialize the stack with the start index {x, y}
//        stack.push(new int[]{x, y});
//
//        // Loop until the stack is empty
//        while (!stack.isEmpty()) {
//            int[] current = stack.pop();
//            int curRow = current[0];
//            int curCol = current[1];
//
//            // Set the corresponding cell's revealed attribute as true
//            field[curRow][curCol].setRevealed(true);
//
//            // Push all valid neighbors' coordinates to the stack
//            for (int i = -1; i <= 1; i++) {
//                for (int j = -1; j <= 1; j++) {
//                    int newRow = curRow + i;
//                    int newCol = curCol + j;
//
//                    // A valid neighbor is one who is in-bounds, has not previously been revealed, and whose status is "0"
//                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns) {
//                        Cell neighbor = field[newRow][newCol];
//                        if (!neighbor.getRevealed() && neighbor.getStatus().equals("0")) {
//                            stack.push(new int[]{newRow, newCol});
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//
//    public void revealMines(int x, int y) {
//        Queue<int[]> queue = new LinkedList<>();
//
//        // Initialize the queue with the start index {x, y}
//        queue.add(new int[]{x, y});
//
//        // Loop until the queue is empty
//        while (!queue.isEmpty()) {
//            int[] current = queue.poll();
//            int curRow = current[0];
//            int curCol = current[1];
//
//            // Set the corresponding cell's revealed attribute as true
//            field[curRow][curCol].setRevealed(true);
//
//            // If the current cell is the finish point (a mine), then break from the loop
//            if (field[curRow][curCol].getStatus().equals("M")) {
//                break;
//            }
//
//            // Enqueue all reachable neighbors that are in-bounds and have not already been visited,
//            // regardless of their statuses
//            for (int i = -1; i <= 1; i++) {
//                for (int j = -1; j <= 1; j++) {
//                    int newRow = curRow + i;
//                    int newCol = curCol + j;
//
//                    // Check if the neighbor is in-bounds and not already revealed
//                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns) {
//                        Cell neighbor = field[newRow][newCol];
//                        if (!neighbor.getRevealed()) {
//                            queue.add(new int[]{newRow, newCol});
//                        }
//                    }
//                }
//            }
//        }
//    }
//
//    public void revealStart(int x, int y) {
//        // Create mines on the field, avoiding the starting point (x, y)
//        createMines(x, y, mines);
//
//        // Evaluate the field to calculate the number of surrounding mines for each cell
//        evaluateField();
//
//        // Reveal enough information for the user to get started
//        revealMines(x, y);
//    }
//
//    public void printMinefield() {
//        for (int row = 0; row < rows; row++) {
//            for (int col = 0; col < columns; col++) {
//                System.out.print(field[row][col].getStatus() + " ");
//            }
//            System.out.println();
//        }
//    }
//
//    public String toString() {
//        StringBuilder sb = new StringBuilder();
//        sb.append("  ");
//        for (int i = 0; i < columns; i++) {
//            sb.append(i % 10).append(" ");
//        }
//        sb.append("\n");
//
//        // Print rows
//        for (int row = 0; row < rows; row++) {
//            sb.append(row % 10).append(" ");
//            for (int col = 0; col < columns; col++) {
//                Cell cell = field[row][col];
//                if (flagged[row][col]) {
//                    sb.append("F").append(" ");
//                } else if (cell.getRevealed()) {
//                    String status = cell.getStatus();
//                    switch (status) {
//                        case "1":
//                            sb.append(ANSI_BLUE).append(status).append(ANSI_GREY_BG).append(" ");
//                            break;
//                        case "0":
//                            sb.append(ANSI_YELLOW).append(status).append(ANSI_GREY_BG).append(" ");
//                            break;
//                        case "2":
//                            sb.append(ANSI_GREEN).append(status).append(ANSI_GREY_BG).append(" ");
//                            break;
//                        case "M":
//                            sb.append(ANSI_RED).append(status).append(ANSI_GREY_BG).append(" ");
//                            break;
//                        default:
//                            sb.append(status).append(" ");
//                            break;
//                    }
//                } else {
//                    sb.append("-").append(" ");
//                }
//            }
//            sb.append("\n");
//        }
//        return sb.toString();
//    }
//}