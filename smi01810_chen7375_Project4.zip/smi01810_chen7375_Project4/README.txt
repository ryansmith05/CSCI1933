// Written by Ryan Smith, smi01810
// Written by Anna Chen, chen7375

Group members: 
    - name: Ryan Smith, x500: smi01810, email: smi01810@d.umn.edu
    - name: Anna Chen, x500: chen7375, email: chen7375@umn.edu

Contributions of each partner:
    - Minefield.java: smi01810 (Ryan)
        - constructor: chen7375 (Anna)
        - evaluateField(): chen7375 (Anna)
        - createMines(int x, int y, int mines): chen7375 (Anna)
        - guess(int x, int y, boolean flag): chen7375 (Anna)
        - gameOver(): chen7375 (Anna)
        - revealZeroes(int x, int y): smi01810 (Ryan)
        - revealMines(int x, int y): smi01810 (Ryan)
        - revealStart(int x, int y): smi01810 (Ryan)
        - printMinefield(): smi01810 (Ryan)
        - toString(): smi01810 (Ryan)
    - Main.java: smi01810 and chen7375 (Ryan and Anna)
    - README.txt: smi01810 and chen7375 (Ryan and Anna)

How to compile and run the program: 
    - You must compile each java class in the zip file in the terminal or intelij.
    - Then run the main method and play the game

Any assumptions:
    - None that we can think of.

Additional features that your project had
    - getRemainingFlags() method: it just returns how many flags the user has left

Any known bugs:
    - pretty sure the revealStart() method does not work properly.

Any outside sources:
    -Idea1: Office Hours, We got help from the TA's on various methods for this project.
    -Idea2: https://www.geeksforgeeks.org this helped us remember how queues and stacks work
    -Idea3: Q2Gen.java on canvas for initializing a queue
    -Idea4: Stack2Gen.java on canvas page, used this to help initialize a stack.


Integrity statement: 
    -“I certify that the information contained in this README
      file is complete and accurate. I have both read and followed the course policies
      in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
        - Ryan Smith
        - Anna Chen