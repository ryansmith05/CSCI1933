// Written by Ryan Smith, smi01810

Group members: 
    - name: Ryan Smith, x500: smi01810, email: smi01810@d.umn.edu

How to compile and run the program: 
    - You must compile each java class in the Project1 zip file in the terminal. The files are Circle.java, Triangle.Java, Rectangle.java, Canvas.java, and FractalDrawer.java
    - Then run FractalDrawer.java in the terminal. 
    - when you run FractalDrawer.java, It will ask you to type in the desired object you want to create a fractal for and then press return.
    - After you press enter you will be redirected to a canvas page that has the fractal on it. 

Any assumptions:
    - None that I can think of.

Any known bugs:
    - You must close the canvas window to terminate the program otherwise you can use control + C to stop the program.
    - You may need to resize the canvas window to see the whole fractal depending on the starting radius, width, and height.

Any outside sources:
    -Idea1: Math.PI I looked this up and used this in the my Circle.java file to get the value of pie for the calculatePerimeter method
    -Idea2: Math.POW I looked this up and used this in the my Circle.java file to square the radius to calculate the area of the circle 
    -Idea3: For drawRectangleFractal, my brother(a computer science major at Oregon State University) helped me figure out how to output 4 new rectangles at each corner of the rectangle  

Integrity statement: 
    -“I certify that the information contained in this README
      file is complete and accurate. I have both read and followed the course policies
      in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
        - Ryan Smith