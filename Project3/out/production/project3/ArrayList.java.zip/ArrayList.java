public class ArrayList<T extends Comparable<T>> implements List<T>{

    private T[] a; //an array of objects
    private boolean isSorted; // tells us if the list is sorted
    private int howMany; // tells us how many non-null elements are in the list

    public ArrayList() {
        a = (T[]) new Comparable[2];
        howMany = 0;
        isSorted = true;
    }

    @Override
    public boolean add(T element) {
        if (element == null) {
            return false;
        }
        if (howMany == a.length) {
            // if the array is full, double the size of the array
            T[] biggerArray = (T[]) new Comparable[a.length * 2];
            System.arraycopy(a, 0, biggerArray, 0, a.length);
            a = biggerArray;
        }
        a[howMany++] = element;
        isSorted = checkIfSorted(); // checks if the element that is added breaks the sorted order
        return true;
    }

    @Override
    public boolean add(int index, T element) {
        if (element == null || index < 0 || index > howMany) {
            return false;
        }
        if (howMany == a.length) {
            // if the array is full, double the size of the array
            T[] biggerArray = (T[]) new Comparable[a.length * 2];
            System.arraycopy(a, 0, biggerArray, 0, a.length);
            a = biggerArray;
        }
        if (index < howMany) {
            // shift all elements to the right starting at the end
            for (int i = howMany - 1; i >= index; i--) {
                a[i + 1] = a[i];
            }
        }
        a[index] = element;
        howMany++;
        isSorted = checkIfSorted();
        return true;
    }

    @Override
    public void clear() {
        //set all indices to null
        for (int i = 0; i < a.length; i++){
            a[i] = null;
        }
        isSorted = true;
        howMany = 0;
        a = (T[]) new Comparable[2];
    }

    @Override
    public T get(int index) {
        if ((index < 0) || (index > howMany - 1)) {
            return null;
        }
        else {
            return a[index];
        }
    }

    @Override
    public int indexOf(T element) {
        if (element == null){
            return -1;
        }
        for (int i = 0; i < a.length; i++) {
                if (a[i] == element) {
                    return i;
                }
        }
        return -1;
    }

    @Override
    public boolean isEmpty() {
        if (howMany == 0){
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public int size() {
        return howMany;
    }

    @Override
    public void sort() {
        if (isSorted) {
            return;
        }
        //insertion sort algorithm
        for (int i = 1; i < howMany; i++) {
            T key = a[i];
            int j = i - 1;
            while (j >= 0 && a[j].compareTo(key) > 0) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = key;
        }
        isSorted = true;
    }

    @Override
    public T remove(int index) {
        if (index < 0 || index >= howMany){
            return null;
        }
        T temp = a[index];
        a[index] = null;
        for (int i = index; i < a.length - 1; i++){
            a[i] = a[i + 1];
        }
        howMany--;
        isSorted = checkIfSorted();
        return temp;
    }

    @Override
    public void equalTo(T element) {
        if (element == null){
            return;
        }
        int rightIndex = 0;
        for (int i = 0; i < howMany; i++){
            if (a[i] == element){
                if (rightIndex != i){
                    a[rightIndex] = a[i];
                }
                rightIndex++;
            }
        }
        howMany = rightIndex;
        isSorted = true;
    }

    @Override
    public void reverse() {
        for(int i = 0; i < howMany/2; i++){
            T temp = a[i];
            a[i] = a[howMany - i - 1];
            a[howMany - i - 1] = temp;
        }
        isSorted = checkIfSorted();
    }

    @Override
    public void merge(List<T> otherList) {
        // If otherList is null, do not attempt to merge
        if (otherList == null) {
            return;
        }
        // Cast otherList to either ArrayList<T> or LinkedList<T>
        ArrayList<T> other = (ArrayList<T>) otherList;

        // Sort both lists
        this.sort();
        other.sort();

        // Merge the two sorted lists
        int i = 0;
        int j = 0;
        T[] tempArray = (T[]) new Comparable[this.size() + other.size()];
        int k = 0;
        while (i < this.size() && j < other.size()) {
            if (this.get(i).compareTo(other.get(j)) < 0) {
                tempArray[k] = this.get(i);
                i++;
            }
            else {
                tempArray[k] = other.get(j);
                j++;
            }
            k++;
        }
        while (i < this.size()) {
            tempArray[k] = this.get(i);
            i++;
            k++;
        }
        while (j < other.size()) {
            tempArray[k] = other.get(j);
            j++;
            k++;
        }
        a = tempArray;
        this.howMany = k;
        isSorted = checkIfSorted();
    }

    @Override
    public boolean rotate(int n) {
        if (n <= 0 || howMany <= 1) {
            return false;
        }
        int rotations = n % howMany;
        if (rotations == 0){
            return true;
        }
        for (int i = 0; i < rotations; i++){
           T lastElement = a[howMany - 1];
           for (int j = howMany -1; j > 0; j--){
               a[j] = a[j - 1];
           }
           a[0] = lastElement;
        }
        isSorted = checkIfSorted();
        return true;
    }

    public boolean checkIfSorted(){ //checks if the array list is in a sorted order
        isSorted = true;
        for (int i = 0; i < howMany - 1; i++){
            if (a[i].compareTo(a[i +1]) > 0){
                isSorted = false;
            }
        }
        return isSorted;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < howMany; i++) {
            sb.append(a[i].toString()).append("\n");
        }
        return sb.toString();
    }
    @Override
    public boolean isSorted() {
        return isSorted;
    }

}
