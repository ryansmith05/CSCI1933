import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Minefield {
    /**
     * Global Section
     */
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE_BRIGHT = "\u001b[34;1m";
    public static final String ANSI_BLUE = "\u001b[34m";
    public static final String ANSI_RED_BRIGHT = "\u001b[31;1m";
    public static final String ANSI_RED = "\u001b[31m";
    public static final String ANSI_GREEN = "\u001b[32m";
    public static final String ANSI_GREY_BG = "\u001b[0m";

    private int rows;
    private int columns;
    private int flags;
    private int mines;
    private Cell[][] field;
    private boolean gameOver;
    private boolean[][] flagged;


    /**
     * Constructor
     *
     * @param rows    Number of rows.
     * @param columns Number of columns.
     * @param flags   Number of flags, should be equal to mines
     */
    public Minefield(int rows, int columns, int flags) {
        this.rows = rows;
        this.columns = columns;
        this.flags = flags;
        this.mines = flags;
        this.field = new Cell[rows][columns];
        this.gameOver = false;
        this.flagged = new boolean[rows][columns];
        // Initialize all cells
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                field[row][col] = new Cell(false, "0");
            }
        }
    }

    /**
     * evaluateField
     *
     * @function When a mine is found in the field, calculate the surrounding 9x9 tiles values. If a mine is found, increase the count for the square.
     */
    public void evaluateField() {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                if (!field[row][col].getStatus().equals("M")) {
                    int minesCount = 0;

                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            int newRow = row + i;
                            int newCol = col + j;

                            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns && field[newRow][newCol].getStatus().equals("M")) {
                                minesCount++;
                                field[row][col].setStatus(Integer.toString(minesCount));

                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * createMines
     *
     * @param x     Start x, avoid placing on this square.
     * @param y     Start y, avoid placing on this square.
     * @param mines Number of mines to place.
     */

    public void createMines(int x, int y, int mines) {
        Random random = new Random();
        int placedMines = 0;

        while (placedMines < mines) {
            int row = random.nextInt(rows);
            int col = random.nextInt(columns);

            // Avoid placing a mine on the starting coordinates
            if (row == x && col == y) {
                continue;
            }

            // Check if the cell is empty and not already a mine
            if (field[row][col] == null || !field[row][col].getStatus().equals("M")) {
                field[row][col] = new Cell(false, "M");
                placedMines++;
            }
        }
    }

    /**
     * guess
     *
     * @param x    The x value the user entered.
     * @param y    The y value the user entered.
     * @param flag A boolean value that allows the user to place a flag on the corresponding square.
     * @return boolean Return false if guess did not hit mine or if flag was placed, true if mine found.
     */
    public boolean guess(int x, int y, boolean flag) {
// Check if the guess is in bounds
        if (x < 0 || x >= rows || y < 0 || y >= columns) {
            return false;
        }
        Cell cell = field[x][y];

        // If the user wishes to place a flag
        if (flag) {
            if (!cell.getRevealed()) {
                if (flagged[x][y]) {
                    flagged[x][y] = false;
                    flags++;
                } else if (flags > 0) {
                    flagged[x][y] = true;
                    flags--;
                }
            }
            return false;
        }

// If the cell is already revealed, do nothing
        if (cell.getRevealed()) {
            return false;
        }
// Reveal the cell
        cell.setRevealed(true);
// If the user hits a cell with a '0' status
        if (cell.getStatus().equals("0")) {
            revealZeroes(x, y);
            return false;
        }
// If the user hits a mine, end the game
        if (cell.getStatus().equals("M")) {
            gameOver = true;
            return true;
        }

        return false;
    }
    public int getFlagsRemaining() {
        return flags;
    }
    /**
     * gameOver
     *
     * @return boolean Return false if game is not over and squares have yet to be revealed, otheriwse return true.
     */
    public boolean gameOver() {
        return gameOver;
    }

    /**
     * revealField
     * <p>
     * This method should follow the psuedocode given.
     * Why might a stack be useful here rather than a queue?
     *
     * @param x The x value the user entered.
     * @param y The y value the user entered.
     */
    public void revealZeroes(int x, int y) {
        Stack1Gen<int[]> stack = new Stack1Gen<>();

        // Initialize the stack with the start index {x, y}
        stack.push(new int[]{x, y});

        // Loop until the stack is empty
        while (!stack.isEmpty()) {
            int[] current = stack.pop();
            int curRow = current[0];
            int curCol = current[1];

            // Set the corresponding cell's revealed attribute as true
            field[curRow][curCol].setRevealed(true);

            // Push all valid neighbors' coordinates to the stack
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    int newRow = curRow + i;
                    int newCol = curCol + j;

                    // A valid neighbor is one who is in-bounds, has not previously been revealed, and whose status is "0"
                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns) {
                        Cell neighbor = field[newRow][newCol];
                        if (!neighbor.getRevealed() && neighbor.getStatus().equals("0")) {
                            stack.push(new int[]{newRow, newCol});
                        }
                    }
                }
            }
        }
    }


    /**
     * revealMines
     * <p>
     * This method should follow the psuedocode given.
     * Why might a queue be useful for this function?
     *
     * @param x The x value the user entered.
     * @param y The y value the user entered.
     */

//    This method will help us reveal enough information for the user to get started at the beginning of
//    each game. The image at the bottom shows the desired output. The goal of the algorithm is to
//    loop until a mine is found. This will reveal enough of the field to help the user. We are instead
//    using a queue here. The pseudo-code is as follows:
//            • Initialize a queue with the start index {x, y}. This should be the same x and y that were
//    passed into the method.
//            • Loop until the queue is empty:
//            – Dequeue the front cell of the queue.
//– Set the corresponding cell’s revealed attribute as true.
//            – If the current cell is the finish point, meaning that the current cell is a mine, then break
//    from the loop. The algorithm is complete.
//            – Enqueue all reachable neighbors that are in-bounds and have not already been visited,
//    regardless of their statuses.
    public void revealMines(int x, int y) {
        Queue<int[]> queue = new LinkedList<>();

        // Initialize the queue with the start index {x, y}
        queue.add(new int[]{x, y});

        // Loop until the queue is empty
        while (!queue.isEmpty()) {
            int[] current = queue.poll();
            int curRow = current[0];
            int curCol = current[1];

            // Set the corresponding cell's revealed attribute as true
            field[curRow][curCol].setRevealed(true);

            // If the current cell is the finish point (a mine), then break from the loop
            if (field[curRow][curCol].getStatus().equals("M")) {
                break;
            }

            // Enqueue all reachable neighbors that are in-bounds and have not already been visited,
            // regardless of their statuses
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    int newRow = curRow + i;
                    int newCol = curCol + j;

                    // Check if the neighbor is in-bounds and not already revealed
                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns) {
                        Cell neighbor = field[newRow][newCol];
                        if (!neighbor.getRevealed()) {
                            queue.add(new int[]{newRow, newCol});
                        }
                    }
                }
            }
        }
    }

    /**
     * revealStart
     *
     * @param x The x value the user entered.
     * @param y The y value the user entered.
     */
    public void revealStart(int x, int y) {
        // Create mines on the field, avoiding the starting point (x, y)
        createMines(x, y, mines);

        // Evaluate the field to calculate the number of surrounding mines for each cell
        evaluateField();

        // Reveal enough information for the user to get started
        revealMines(x, y);
    }

    /**
     * printMinefield
     *
     * @fuctnion This method should print the entire minefield, regardless if the user has guessed a square.
     * *This method should print out when debug mode has been selected.
     */
    public void printMinefield() {
        // Print column numbers
        System.out.print("  ");
        for (int i = 0; i < columns; i++) {
            System.out.print(i % 10 + " ");
        }
        System.out.println();

        // Print rows
        for (int row = 0; row < rows; row++) {
            // Print row number
            System.out.print(row % 10 + " ");

            // Print cells
            for (int col = 0; col < columns; col++) {
                Cell cell = field[row][col];
                String status = cell.getStatus();

                if ("1".equals(status)) {
                    System.out.print(ANSI_BLUE + status + ANSI_GREY_BG + " ");
                } else if ("0".equals(status)) {
                    System.out.print(ANSI_YELLOW + status + ANSI_GREY_BG + " ");
                } else if ("2".equals(status)) {
                    System.out.print(ANSI_GREEN + status + ANSI_GREY_BG + " ");
                } else if ("M".equals(status)) {
                    System.out.print(ANSI_RED + status + ANSI_GREY_BG + " ");
                } else if ("3".equals(status)) {
                    System.out.print(ANSI_RED + status + ANSI_GREY_BG +" ");
                } else {
                    System.out.print(status + " ");
                }
            }
            System.out.println();
        }
    }

    /**
     * toString
     *
     * @return String The string that is returned only has the squares that have been revealed to the user or that the user has guessed.
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("  ");
        for (int i = 0; i < columns; i++) {
            sb.append(i % 10).append(" ");
        }
        sb.append("\n");

        // Print rows
        for (int row = 0; row < rows; row++) {
            sb.append(row % 10).append(" ");
            for (int col = 0; col < columns; col++) {
                Cell cell = field[row][col];
                if (flagged[row][col]) {
                    sb.append("F").append(" ");
                } else if (cell.getRevealed()) {
                    String status = cell.getStatus();
                    if ("1".equals(status)) {
                        sb.append(ANSI_BLUE).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("0".equals(status)) {
                        sb.append(ANSI_YELLOW).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("2".equals(status)) {
                        sb.append(ANSI_GREEN).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("M".equals(status)) {
                        sb.append(ANSI_RED).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("3".equals(status)) {
                        sb.append(ANSI_RED).append(status).append(ANSI_GREY_BG).append(" ");
                    } else {
                        sb.append(status).append(" ");
                    }
                } else {
                    sb.append("-").append(" ");
                }
            }
            sb.append("\n");
        }
        return sb.toString();
    }
}