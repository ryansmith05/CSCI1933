// Written by Ryan Smith, smi01810
// Written by Anna Chen, chen7375

Group members: 
    - name: Ryan Smith, x500: smi01810, email: smi01810@d.umn.edu
    - name: Anna Chen, x500: chen7375, email: chen7375@umn.edu

Contributions of each partner:
    - ArrayList.java; smi01810 (Ryan)
    - LinkedList.java chen7375 (Anna)
    - analysis.pdf: smi01810 and chen7375 (Ryan and Anna)
    - README.txt: smi01810 and chen7375 (Ryan and Anna)

How to compile and run the program: 
    - You must compile each java class in the zip file in the terminal or intelij.
    - Then run the test files that apply to ArrayList.java or LinkedList.java

Any assumptions:
    - None that we can think of.

Additional features that your project had
    - We added a helper function to ArrayList.java called checkIfSorted() and it checks if the elements are in a sorted order and updates the isSorted variable to true or false

Any known bugs:
    - None that we are aware of

Any outside sources:
    -Idea1: Office Hours, I got help from the TA's on various methods for this project.
    -Idea2: https://www.geeksforgeeks.org/merge-two-sorted-arrays/ this helped me with the format for the merge method
    -Idea3: https://www.scaler.com/topics/reverse-an-array-in-java/ this helped me figure out how to reverse the array list properly
    -Idea4: insert.java on canvas page, used this code to sort the array using insertion sort for the sort method
    -Idea5: Stack2Gen.java on canvas page, used this to help create the first add method.
    -Idea6: StackOverflow, use this for a question regarding to the runtime complexity of one of the methods

Integrity statement: 
    -“I certify that the information contained in this README
      file is complete and accurate. I have both read and followed the course policies
      in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
        - Ryan Smith
        - Anna Chen