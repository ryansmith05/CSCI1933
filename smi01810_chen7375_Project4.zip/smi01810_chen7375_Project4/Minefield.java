// Written by Ryan Smith, smi01810
// Written by Anna Chen, chen7375

import java.util.Queue;
import java.util.Random;

public class Minefield {
    /**
    Global Section
    */
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE_BRIGHT = "\u001b[34;1m";
    public static final String ANSI_BLUE = "\u001b[34m";
    public static final String ANSI_RED_BRIGHT = "\u001b[31;1m";
    public static final String ANSI_RED = "\u001b[31m";
    public static final String ANSI_GREEN = "\u001b[32m";
    public static final String ANSI_GREY_BG = "\u001b[0m";

    // We added these variables
    private int rows;
    private int columns;
    private int flags;
    private int mines;
    private Cell[][] field;
    private boolean isGameOver;
    private boolean[][] flagged;

    /**
     * Constructor
     * @param rows       Number of rows.
     * @param columns    Number of columns.
     * @param flags      Number of flags, should be equal to mines
     */
    public Minefield(int rows, int columns, int flags) {
        this.rows = rows;
        this.columns = columns;
        this.flags = flags;
        this.mines = flags;
        this.field = new Cell[rows][columns];
        this.isGameOver = false;
        this.flagged = new boolean[rows][columns];
        // Initialize all cells
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                field[row][col] = new Cell(false, "0");
            }
        }
    }
    /**
     * evaluateField
     *
     * @function When a mine is found in the field, calculate the surrounding 9x9 tiles values. If a mine is found, increase the count for the square.
     */
    public void evaluateField() {
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                if (!field[row][col].getStatus().equals("M")) {
                    int minesCount = 0;
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            int newRow = row + i;
                            int newCol = col + j;

                            if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < columns && field[newRow][newCol].getStatus().equals("M")) {
                                minesCount++;
                                field[row][col].setStatus(Integer.toString(minesCount));

                            }
                        }
                    }
                }
            }
        }
    }
    /**
     * createMines
     *
     * @param x       Start x, avoid placing on this square.
     * @param y        Start y, avoid placing on this square.
     * @param mines      Number of mines to place.
     */
    public void createMines(int x, int y, int mines) {
        Random random = new Random();
        int placedMines = 0;

        while (placedMines < mines) {
            int row = random.nextInt(rows);
            int col = random.nextInt(columns);

            // Avoid placing a mine on the starting coordinates
            if (row == x && col == y) {
                continue;
            }

            // Check if the cell is empty and not already a mine
            if (field[row][col] == null || !field[row][col].getStatus().equals("M")) {
                field[row][col] = new Cell(false, "M");
                placedMines++;
            }
        }
    }

    /**
     * guess
     *
     * @param x       The x value the user entered.
     * @param y       The y value the user entered.
     * @param flag    A boolean value that allows the user to place a flag on the corresponding square.
     * @return boolean Return false if guess did not hit mine or if flag was placed, true if mine found.
     */
    public boolean guess(int x, int y, boolean flag) {
        // Check if the guess is in bounds
        if (x < 0 || x >= rows || y < 0 || y >= columns) {
            return false;
        }
        Cell cell = field[x][y];

        // If the user wishes to place a flag
        if (flag) {
            if (!cell.getRevealed()) {
                if (flagged[x][y]) {
                    flagged[x][y] = false;
                    flags++;
                } else if (flags > 0) {
                    flagged[x][y] = true;
                    flags--;
                }
            }
            return false;
        }
        // If the cell is already revealed, do nothing
        if (cell.getRevealed()) {
            return false;
        }
        // Reveal the cell
        cell.setRevealed(true);

        // If the user hits a cell with a '0' status
        if (cell.getStatus().equals("0")) {
            revealZeroes(x, y);
            return false;
        }
        // If the user hits a mine, end the game
        if (cell.getStatus().equals("M")) {
            isGameOver = true;
            return true;
        }

        return false;
    }

    public int getRemainingFlags() {
        return flags;
    }

    /**
     * gameOver
     *
     * @return boolean Return false if game is not over and squares have yet to be revealed, otheriwse return true.
     */
    public boolean gameOver() {
        return isGameOver;
    }

    /**
     * revealField
     *
     * This method should follow the psuedocode given.
     * Why might a stack be useful here rather than a queue?
     *
     * @param x      The x value the user entered.
     * @param y      The y value the user entered.
     */
    public void revealZeroes(int x, int y) {
        Stack1Gen<int[]> myStack = new Stack1Gen<>();
        myStack.push(new int[]{x, y});
        while (!myStack.isEmpty()){
            int[] coordinates = myStack.pop();
            int newX = coordinates[0];
            int newY = coordinates[1];

            field[newX][newY].setRevealed(true); //set revealed to true

            if ((0 <= newX - 1 && newX - 1 < field.length) && (!field[newX - 1][newY].getRevealed()) && (field[newX - 1][newY].getStatus().equals("0"))){ //check left
                myStack.push(new int[]{newX - 1, newY});
            }
            if ((0 <= newX + 1 && newX + 1 < field.length) && (!field[newX + 1][newY].getRevealed()) && (field[newX + 1][newY].getStatus().equals("0"))){ //check right
                myStack.push(new int[]{newX + 1, newY});
            }
            if ((0 <= newY - 1 && newY - 1 < field.length) && (!field[newX][newY - 1].getRevealed()) && (field[newX][newY - 1].getStatus().equals("0"))){ //check up
                myStack.push(new int[]{newX, newY - 1});
            }
            if ((0 <= newY + 1 && newY + 1 < field.length) && (!field[newX][newY + 1].getRevealed()) && (field[newX][newY + 1].getStatus().equals("0"))){ //check down
                myStack.push(new int[]{newX, newY + 1});
            }
        }
    }

    /**
     * revealMines
     *
     * This method should follow the psuedocode given.
     * Why might a queue be useful for this function?
     *
     * @param x     The x value the user entered.
     * @param y     The y value the user entered.
     */
    public void revealMines(int x, int y) {
        Q1Gen<int[]> myQueue = new Q1Gen<>();
        myQueue.add(new int[]{x, y});

        while (myQueue.length() != 0){
            int[] coordinates = myQueue.remove();
            int newX = coordinates[0];
            int newY = coordinates[1];

            field[newX][newY].setRevealed(true); //set revealed to true

            if (field[newX][newY].getStatus().equals("M")){ // found a mine, stop searching
                break;
            }
            if ((0 <= newX - 1 && newX - 1 < field.length) && (!field[newX - 1][newY].getRevealed())){ //add left
                myQueue.add(new int[]{newX - 1, newY});
            }
            if ((0 <= newX + 1 && newX + 1 < field.length) && (!field[newX + 1][newY].getRevealed())){ //add right
                myQueue.add(new int[]{newX + 1, newY});
            }
            if ((0 <= newY - 1 && newY - 1 < field.length) && (!field[newX][newY - 1].getRevealed())){ //add up
                myQueue.add(new int[]{newX, newY - 1});
            }
            if ((0 <= newY + 1 && newY + 1 < field.length) && (!field[newX][newY + 1].getRevealed())){ //add down
                myQueue.add(new int[]{newX, newY + 1});
            }
        }
    }

    /**
     * revealStart
     *
     * @param x       The x value the user entered.
     * @param y       The y value the user entered.
     */
    public void revealStart(int x, int y) {
        // Create mines on the field, avoiding the starting point (x, y)
        createMines(x, y, mines);

        // Calculate the number of surrounding mines for each cell
        evaluateField();

        // Reveal enough information for the user to get started
        revealMines(x, y);
    }
    /**
     * printMinefield
     *
     * @fuctnion This method should print the entire minefield, regardless if the user has guessed a square.
     * *This method should print out when debug mode has been selected. 
     */
    public void printMinefield() {
        // Print column numbers
        System.out.print("  ");
        for (int i = 0; i < columns; i++) {
            System.out.print(i % 10 + " ");
        }
        System.out.println();

        // Print rows
        for (int row = 0; row < rows; row++) {
            // Print row number
            System.out.print(row % 10 + " ");

            // Print cells
            for (int col = 0; col < columns; col++) {
                Cell cell = field[row][col];
                String status = cell.getStatus();

                if ("0".equals(status)) {
                    System.out.print(ANSI_YELLOW + status + ANSI_GREY_BG + " ");
                } else if ("1".equals(status)) {
                    System.out.print(ANSI_BLUE + status + ANSI_GREY_BG + " ");
                } else if ("2".equals(status)) {
                    System.out.print(ANSI_GREEN + status + ANSI_GREY_BG + " ");
                } else if ("3".equals(status)) {
                    System.out.print(ANSI_RED + status + ANSI_GREY_BG + " ");
                } else if ("4".equals(status)) {
                    System.out.println(ANSI_BLUE_BRIGHT + status + ANSI_GREY_BG + " ");
                } else if ("M".equals(status)) {
                    System.out.print(ANSI_RED_BRIGHT + status + ANSI_GREY_BG + " ");
                } else {
                    System.out.print(status + " ");
                }
            }
            System.out.println();
        }
    }
    /**
     * toString
     *
     * @return String The string that is returned only has the squares that has been revealed to the user or that the user has guessed.
     */
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("  ");
        for (int i = 0; i < columns; i++) {
            result.append(i % 10).append(" ");
        }
        result.append("\n");

        // Print rows
        for (int row = 0; row < rows; row++) {
            result.append(row % 10).append(" ");
            for (int col = 0; col < columns; col++) {
                Cell cell = field[row][col];
                if (flagged[row][col]) {
                    result.append("F").append(" ");
                } else if (cell.getRevealed()) {
                    String status = cell.getStatus();
                    if ("0".equals(status)) {
                        result.append(ANSI_YELLOW).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("1".equals(status)) {
                        result.append(ANSI_BLUE).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("2".equals(status)) {
                        result.append(ANSI_GREEN).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("3".equals(status)) {
                        result.append(ANSI_RED).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("4".equals(status)) {
                        result.append(ANSI_BLUE_BRIGHT).append(status).append(ANSI_GREY_BG).append(" ");
                    } else if ("M".equals(status)) {
                        result.append(ANSI_RED_BRIGHT).append(status).append(ANSI_GREY_BG).append(" ");
                    } else {
                        result.append(status).append(" ");
                    }
                } else {
                    result.append("-").append(" ");
                }
            }
            result.append("\n");
        }
        return result.toString();
    }
}
